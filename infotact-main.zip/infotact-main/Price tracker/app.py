from flask import Flask, render_template, request, redirect, url_for
import json
import price_tracker

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/add-product", methods=["POST"])
def add_product():
    url = request.form["url"]
    desired_price = float(request.form["desired_price"])

    cfg = price_tracker.load_config()
    cfg["products"].append({
        "name": url.split("/")[-2],  # just a placeholder name
        "url": url,
        "desired_price": desired_price
    })

    # Save back into config file
    with open(cfg["storage"]["config_json"], "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=4)

    return redirect(url_for("check_prices"))

@app.route("/check-prices")
def check_prices():
    cfg = price_tracker.load_config()
    price_tracker.ensure_files(cfg)
    price_tracker.check_once(cfg)

    with open(cfg["storage"]["latest_json"], "r", encoding="utf-8") as f:
        data = json.load(f)

    return render_template("results.html", results=data)

if __name__ == "__main__":
    app.run(debug=True)

from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Temporary storage for products (later you can use database)
products = []

@app.route("/")
def index():
    return render_template("index.html", products=products)

@app.route("/add-product", methods=["POST"])
def add_product():
    url = request.form.get("url")
    price = request.form.get("price")
    if url and price:
        products.append({"url": url, "price": price})
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)

