import os, re, json, time, random, logging, csv, datetime as dt
from pathlib import Path

import requests
from bs4 import BeautifulSoup
from dotenv import load_dotenv

# ---------- Setup ----------
load_dotenv()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(), logging.FileHandler("price_tracker.log", encoding="utf-8")]
)

EMAIL_HOST = os.getenv("EMAIL_HOST")
EMAIL_PORT = int(os.getenv("EMAIL_PORT", "587"))
EMAIL_USER = os.getenv("EMAIL_USER")
EMAIL_PASS = os.getenv("EMAIL_PASS")
EMAIL_TO   = os.getenv("EMAIL_TO", EMAIL_USER)

def load_config(path="config.json"):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def ensure_files(cfg):
    Path("data").mkdir(exist_ok=True)
    csv_path = Path(cfg["storage"]["history_csv"])
    if not csv_path.exists():
        csv_path.write_text("timestamp,name,url,title,price,currency\n", encoding="utf-8")

def money_to_float(text: str) -> tuple[float, str]:
    """Extract first numeric amount. Handles '£51.77', '1,299.00', '1.299,00'."""
    cur = "".join(ch for ch in text if not ch.isdigit() and ch not in ".,").strip()
    # pull number part
    m = re.search(r"[\d.,]+", text)
    if not m:
        raise ValueError(f"Could not parse price from: {text!r}")
    raw = m.group(0)

    # normalize thousand/decimal separators
    if "," in raw and "." in raw:
        # assume comma thousands, dot decimal (1,299.99)
        num = float(raw.replace(",", ""))
    elif "," in raw and "." not in raw:
        # assume European decimal (1.299,99 or 51,77 -> replace comma with dot)
        num = float(raw.replace(".", "").replace(",", "."))
    else:
        num = float(raw)

    return num, cur

def fetch_html(url: str, headers: dict, timeout: int) -> str:
    with requests.Session() as s:
        s.headers.update(headers)
        resp = s.get(url, timeout=timeout)
        resp.raise_for_status()
        return resp.text

def parse_product(html: str, price_sel: str, title_sel: str | None = None):
    soup = BeautifulSoup(html, "lxml")
    price_el = soup.select_one(price_sel)
    if not price_el:
        raise ValueError(f"Price element not found with selector: {price_sel!r}")
    price_text = price_el.get_text(strip=True)
    price, currency = money_to_float(price_text)
    title = None
    if title_sel:
        t = soup.select_one(title_sel)
        if t:
            title = t.get_text(strip=True)
    if not title:
        title = (soup.title.get_text(strip=True) if soup.title else "Unknown Product")
    return title, price, currency

def record_history(cfg, row):
    csv_path = Path(cfg["storage"]["history_csv"])
    with csv_path.open("a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(row)

def update_latest(cfg, payload):
    json_path = Path(cfg["storage"]["latest_json"])
    json_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

def send_email_alert(subject: str, body: str):
    if not (EMAIL_HOST and EMAIL_USER and EMAIL_PASS and EMAIL_TO):
        logging.warning("Email not configured; skipping alert.")
        return
    import smtplib
    from email.mime.text import MIMEText

    msg = MIMEText(body, "plain", "utf-8")
    msg["Subject"] = subject
    msg["From"] = EMAIL_USER
    msg["To"] = EMAIL_TO

    with smtplib.SMTP(EMAIL_HOST, EMAIL_PORT) as server:
        server.starttls()
        server.login(EMAIL_USER, EMAIL_PASS)
        server.send_message(msg)

def check_once(cfg):
    ensure_files(cfg)
    results = []
    alerts = []

    req_cfg = cfg.get("request", {})
    headers = req_cfg.get("headers", {"User-Agent": "PriceTracker/1.0"})
    timeout = int(req_cfg.get("timeout_sec", 20))
    sleep_lo, sleep_hi = req_cfg.get("random_sleep_range_sec", [1, 3])

    for p in cfg["products"]:
        name = p["name"]
        url = p["url"]
        price_sel = p["price_selector"]
        title_sel = p.get("title_selector")
        desired = float(p["desired_price"])
        currency_hint = p.get("currency_hint", "")

        try:
            html = fetch_html(url, headers, timeout)
            title, price, currency_found = parse_product(html, price_sel, title_sel)
            currency = currency_hint or currency_found

            ts = dt.datetime.now(dt.UTC).isoformat()
            record_history(cfg, [ts, name, url, title, price, currency])

            result = {"timestamp": ts, "name": name, "url": url,
                      "title": title, "price": price, "currency": currency,
                      "desired_price": desired}
            results.append(result)

            if price <= desired:
                alerts.append(result)

            # polite delay to avoid hammering the site
            time.sleep(random.uniform(sleep_lo, sleep_hi))

            logging.info(f"{name}: {currency}{price:.2f} (target {desired:.2f})")

        except Exception as e:
            logging.exception(f"Failed for {name} ({url}): {e}")
            continue

    update_latest(cfg, {"checked_at_utc": dt.datetime.now(dt.UTC).isoformat(), "results": results})


    if alerts:
        lines = []
        for a in alerts:
            lines.append(f"{a['name']} now {a['currency']}{a['price']:.2f} (target {a['desired_price']:.2f})\n{a['url']}")
        body = "\n\n".join(lines)
        send_email_alert("Price Alert(s) Triggered", body)

if __name__ == "__main__":
    cfg = load_config()
    check_once(cfg)
